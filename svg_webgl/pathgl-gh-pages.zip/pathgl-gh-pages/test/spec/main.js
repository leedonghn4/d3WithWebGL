describe('PathGL', function() {
  it('should be in the global scope', function() {
    expect(pathgl).to.equal(window.pathgl);
  });
});
