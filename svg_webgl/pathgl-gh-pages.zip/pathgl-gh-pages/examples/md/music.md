A waveform visualization of a song. 
