A simple particle simulation using physics computed on the gpu.
Click to repel. 
