Intake video stream and swap 50px tiles with images from imgur to create a realtime
video mosaic. 
