function import(svg) {

}x