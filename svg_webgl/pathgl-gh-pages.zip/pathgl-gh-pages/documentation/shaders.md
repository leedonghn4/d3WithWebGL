Most visualizations do not need to rebuffer new data on every frame. PathGL is
designed to exploit this fact, by exposing a powerful set of abstractions that
make GLSL programming radically simpler.

Shaders have 3 types of variables.

1. Uniform
2. Varying
3. Attributes

